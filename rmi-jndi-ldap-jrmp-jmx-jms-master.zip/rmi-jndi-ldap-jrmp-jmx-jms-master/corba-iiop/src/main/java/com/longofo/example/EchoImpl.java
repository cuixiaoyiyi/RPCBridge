package com.longofo.example;

import com.longofo.example.EchoApp.EchoPOA;

public class EchoImpl extends EchoPOA {
    @Override
    public String echoString() {
        return "Hello World!!!";
    }
}
