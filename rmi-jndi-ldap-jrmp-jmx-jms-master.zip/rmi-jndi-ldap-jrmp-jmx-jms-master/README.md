#### rmi-jndi-ldap-jrmp-jmx-jms
rmi、jndi、ldap、jrmp、jmx、jms一些demo测试